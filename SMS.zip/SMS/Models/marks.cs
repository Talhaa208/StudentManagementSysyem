﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SMS.Models
{
    public class marks
    {
        public int course1 { get; set; }
        public int course2 { get; set; }
        public int course3 { get; set; }
        public int course4 { get; set; }
        public int tot { get; set; }
        public int avg { get; set; }
        public string grade { get; set; }



    }
}